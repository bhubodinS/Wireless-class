import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Product Listing',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: ProductListPage(),
    );
  }
}

class Product {
  final String title;
  final String description;
  final int price;
  final Color color;
  final String imagePath;

  Product(this.title, this.description, this.price, this.color, this.imagePath);
}

class ProductWidget extends StatelessWidget {
  final Product product;

  ProductWidget({required this.product});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: product.color,
      child: Row(
        children: <Widget>[
          Image.asset(product.imagePath,
              width: 100, height: 100), // Set your desired image size here
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(product.title,
                      style: TextStyle(color: Colors.white, fontSize: 24)),
                  Text(product.description,
                      style: TextStyle(color: Colors.white)),
                  Text('Price: ${product.price}',
                      style: TextStyle(color: Colors.white)),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class ProductListPage extends StatelessWidget {
  final List<Product> products = [
    Product('iPhone', 'iPhone is the stylist phone ever', 1000, Colors.blue,
        'assets/iphone.jpg'),
    Product('Pixel', 'Pixel is the most featureful phone ever', 800, Colors.red,
        'assets/pixel.jpg'),
    // Add more products here
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Product Listing'),
      ),
      body: ListView.builder(
        itemCount: products.length,
        itemBuilder: (context, index) {
          return ProductWidget(product: products[index]);
        },
      ),
    );
  }
}
