package com.example.page_to_page

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
