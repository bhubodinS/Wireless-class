package com.example.flutter_widget_agmt2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
